
// la función validar() realiza la validación de varios campos de un formulario verificando si están vacíos y mostrando mensajes de error correspondientes en los elementos de error asociados a cada campo
function validar(){
    nombre=document.getElementById('nombre');
    e_nombre= document.getElementById('e_nombre');
    if(nombre.value==""){
        e_nombre.innerHTML="debe ingresar un nombre";
    }


apellido=document.getElementById('apellido');
e_apellido= document.getElementById('e_apellido');
if(apellido.value==""){
    e_apellido.innerHTML="debe ingresar un nombre";
}
direccion=document.getElementById('direccion');
e_direccion= document.getElementById('e_direccion');
if(direccion.value==""){
    e_direccion.innerHTML="debe ingresar una direccion";
}
telefono=document.getElementById('telefono');
e_telefono= document.getElementById('e_telefono');
if(nombre.value==""){
    e_telefono.innerHTML="debe ingresar un telefono";
}
{ 
}
Documento=document.getElementById('Documento');
e_Documento= document.getElementById('e_Documento');
if(nombre.value==""){
    e_Documento.innerHTML="debe ingresar el tipo de documento";
}

}
            