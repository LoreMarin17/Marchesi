// eL código establece las referencias a los elementos principales del carrusel y recopila información relevante, como el ancho de los elementos y los indicadores, que se utilizará más adelante para el funcionamiento del carrusel.
const carousel = document.querySelector('.carousel');
        const carouselContainer = carousel.querySelector('.carousel-container');
        const carouselItems = carousel.querySelectorAll('.carousel-item');
        const carouselItemWidth = carouselItems[0].offsetWidth;
        const carouselIndicators = carousel.querySelectorAll('.carousel-indicators li');

        let position = 0;

        //  se utiliza para mover un carrusel de elementos dentro de un contenedor horizontal.
        function moveToPosition() {
        carouselContainer.style.transform = `translateX(${position}px)`;
        }

        // se encarga de establecer el indicador activo en un carrusel según la posición actual del carrusel.
        function setActiveIndicator() {
        carouselIndicators.forEach((indicator, index) => {
            indicator.classList.toggle('active', index * -carouselItemWidth === position);
        });
        }

        // Dentro de la función, se incrementa el valor de position sumándole carouselItemWidth, que representa el ancho de cada elemento del carrusel. Esto significa que se desplaza el carrusel hacia la izquierda en la medida del ancho de un elemento
        function moveLeft() {
        position += carouselItemWidth;
        if (position > 0) {
            position = -(carouselItemWidth * (carouselItems.length - 1));
        }
        moveToPosition();
        setActiveIndicator();
        }

        // Dentro de la función, se decrementa el valor de position restando carouselItemWidth, que representa el ancho de cada elemento del carrusel. Esto significa que se desplaza el carrusel hacia la derecha en la medida del ancho de un elemento.
        function moveRight() {
        position -= carouselItemWidth;
        if (position < -(carouselItemWidth * (carouselItems.length - 1))) {
            position = 0;
        }
        moveToPosition();
        setActiveIndicator();
        }

        setInterval(moveRight, 5000);